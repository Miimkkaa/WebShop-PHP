When you open the database query:

1. First create a new database.
2. Use the database
3. Then create the table User, afterwards scroll down and create table menu, then create the last table Products.
4. Afterwards you can use the INSERT queries to add values to the tables, keep in mind that admin should be kept like this.
5. When inserting values for menu and products, first run the insert statements for menu, then run the instert statement for products.


// Also when running the program, some files are separated as .html and others as .php (such as login/registration). First run the .html files

// In case registration doesn't work in the project, make sure that the password regex is kept: 
At least 6 characters
At least one lowercase
At least one capital case
At least one number
At least one symbol